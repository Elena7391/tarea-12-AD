package ej11;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;



public class Main {
	
	public static void verOpc() {
		System.out.println("1. Insertar alumno en la BBDD");
		System.out.println("2. Insertar grupo en la BBDD");
		System.out.println("3. Mostrar alumnos de la BBDD");
		System.out.println("4. Guardar todos los alumnos en fichero .bin");
		System.out.println("5. Leer alumnos de fichero .bin e insertarlos en la BBDD");
		System.out.println("6. Modificar nombre de alumno");
		System.out.println("7. Eliminar alumno a partir de NIA");
		System.out.println("8. Eliminar alumno a partir de una palabra en el apellido");
		System.out.println("9. Eliminar alumno a partir de curso");
		System.out.println("10. Guardar alumnos en XML");
		System.out.println("11. Leer fichero XML e insertarlo en la BBDD");
		System.out.println("12. Salir");
	}

	public static void guardarAlumnosEnBIN(Connection conexion) {
		File fich=new File("alumnos.bin");
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(fich);
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			try {
				Statement sentencia=conexion.createStatement();
				String sql="Select * from alumno";
				ResultSet result = sentencia.executeQuery(sql);
				while(result.next()) {
					Alumnos alus=new Alumnos();
					alus.nia=result.getInt("NIA");alus.nombre=result.getString("Nombre");alus.apellidos=result.getString("Apellidos");alus.genero=result.getString("Genero").charAt(0);alus.fecha_nacimiento=LocalDate.parse(result.getString("Fecha_Nacimiento"));alus.ciclo=result.getString("Ciclo");alus.curso=result.getString("Curso");alus.grupo=result.getInt("Grupo");
					oos.writeObject(alus);
				}
				System.out.println("Se han escrito los alumnos en \"alumnos.bin\"");
				result.close();
				sentencia.close(); 
				oos.close();
				fos.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void insertarGrupo(Connection conexion) {
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Escribe el nombre del grupo: ");
	    String grupo = sc.nextLine();
	    
	    try {
	        Statement sentencia = conexion.createStatement();
	        String sql = "INSERT INTO grupo (nombre) VALUES ('" + grupo + "')";
	        sentencia.executeUpdate(sql);
	        System.out.println("Grupo insertado.");
	        sentencia.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	
 	public static void verAlumnosDeBase(Connection conexion) {
 		    try {
 		        Statement sentencia = conexion.createStatement();
 		        String sql = "SELECT a.nia, a.nombre, a.apellidos, a.genero, a.fecha_nacimiento, a.ciclo, g.nombre AS grupo FROM alumno a JOIN grupo g ON a.id_grupo = g.id";
 		        ResultSet result = sentencia.executeQuery(sql);
 		        while (result.next()) {
 		            System.out.println("****************");
 		            System.out.println("NIA: " + result.getInt("nia") + "\tNombre: " + result.getString("nombre") 
 		                               + "\tApellidos: " + result.getString("apellidos"));
 		            System.out.println("Genero: " + result.getString("genero") + "\tFecha de Nacimiento: " + result.getDate("fecha_nacimiento"));
 		            System.out.println("Ciclo: " + result.getString("ciclo") + "\tGrupo: " + result.getString("grupo"));
 		            System.out.println("****************");
 		        }
 		        result.close();
 		        sentencia.close();
 		    } catch (SQLException e) {
 		        e.printStackTrace();
 		    }
 	}
 	
 	public static void hacerAlumno(Connection conexion) {
		Alumnos alus= new Alumnos();
		Scanner sc = new Scanner(System.in);

		System.out.println("Escribe el NIA del alumno: ");
		int nia =sc.nextInt();
		alus.nia=nia;
		System.out.println("Escribe el nombre del alumno: ");
		String nombre=sc.next();
		alus.nombre=nombre;
		System.out.println("Escribe los apellidos del alumno: ");
		String apellidos=sc.next();
		alus.apellidos=apellidos;
		System.out.println("Escribe el género del alumno: ");
		sc.nextLine();
		String gen=sc.nextLine();
		char genero=gen.charAt(0);
		alus.genero=genero; 
		System.out.println("Escribe el año de nacimiento del alumno: ");
		int anio=sc.nextInt();
		System.out.println("Escribe el mes de nacimiento del alumno: ");
		int mes=sc.nextInt();
		System.out.println("Escribe el día de nacimiento del alumno: ");
		int dia=sc.nextInt();
		alus.fecha_nacimiento=LocalDate.of(anio,mes,dia);
		System.out.println("Escribe el ciclo del alumno: ");
		String ciclo=sc.next();
		alus.ciclo=ciclo;
		System.out.println("Escribe el curso del alumno: ");
		String curso=sc.next();
		alus.curso=curso;
		System.out.println("Escribe el id del grupo del alumno: ");
		int grupo=sc.nextInt();
		alus.grupo=grupo;
		
		try {
			Statement sentencia=conexion.createStatement();
			String sql="INSERT INTO alumno () values ("+alus.nia+","+"\""+alus.nombre+"\""+",\""+alus.apellidos+"\",\""+alus.genero+"\",\""+alus.fecha_nacimiento+"\",\""+alus.ciclo+"\",\""+alus.curso+"\",\""+alus.grupo+"\")";
			int resul = sentencia.executeUpdate(sql);
			System.out.println("Se ha creado el alumno en la base de datos");
			sentencia.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static void main(String[] args) {
		try {
			Connection conexion = crearConex();
			Scanner sc=new Scanner(System.in);
			int opc=0;
			do {
				opc = hacerOpcionSeleccionada(conexion, sc);
			}while(opc!=10);
			System.out.println("Fin del programa");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void leerEnXML(Connection conexion, Scanner sc) {
		
		try {
			System.out.println("Escribe la ruta del fichero que quieras leer:");
			String ruta=sc.nextLine();
			ruta=sc.nextLine();
	        Document document = escogerFicheroXML(ruta);
	        NodeList listaAlumnos = document.getElementsByTagName("Alumno");
	        for (int i = 0; i < listaAlumnos.getLength(); i++) {
	            Node nodo = listaAlumnos.item(i);
	            mostrarEInsertarDatosXML(conexion, nodo);
	        }
            System.out.println("Se han añadido los datos a la base de datos.");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	public static Document escogerFicheroXML(String ruta)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document document = builder.parse(new File(ruta));
		document.getDocumentElement().normalize();
		return document;
	}

	public static void mostrarEInsertarDatosXML(Connection conexion, Node nodo) throws SQLException {
		if (nodo.getNodeType() == Node.ELEMENT_NODE) {
		    Element elemento = (Element) nodo;

		    int nia = Integer.parseInt(elemento.getAttribute("NIA"));
		    String nombre = elemento.getElementsByTagName("Nombre").item(0).getTextContent();
		    String apellidos = elemento.getElementsByTagName("Apellidos").item(0).getTextContent();
		    char genero = elemento.getElementsByTagName("Genero").item(0).getTextContent().charAt(0);
		    LocalDate fechaNacimiento = LocalDate.parse(elemento.getElementsByTagName("Fecha_Nacimiento").item(0).getTextContent());
		    String ciclo = elemento.getElementsByTagName("Ciclo").item(0).getTextContent();

		    Element cicloElement = (Element) elemento.getElementsByTagName("Ciclo").item(0);
		    String curso = cicloElement.getAttribute("Curso");
		    String grupo = cicloElement.getAttribute("Grupo");

		    System.out.println("************");
		    System.out.println("NIA: " + nia + "\tNombre: " + nombre + "\tApellidos: " + apellidos);
		    System.out.println("Genero: " + genero + "\tFecha de Nacimiento: " + fechaNacimiento);
		    System.out.println("Ciclo: " + ciclo + "\tCurso: " + curso + ",\tGrupo: " + grupo);

		    String sql = "INSERT INTO alumno VALUES (" +nia + ", '" + nombre + "', '" + apellidos + "', '" + genero + "', '" +fechaNacimiento + "', '" + ciclo + "', '" + curso + "', '" + grupo + "');";
		    Statement sentencia = conexion.createStatement();
		    int resul = sentencia.executeUpdate(sql);
		    sentencia.close();
		}
	}
	
	public static void crearElemento(String nombre, String valor, Element padre, Document document) {
	    Element nuevoElemento = document.createElement(nombre);
	    nuevoElemento.setTextContent(valor);
	    padre.appendChild(nuevoElemento);
	}
	
	public static void guardarEnXML(Connection conexion) throws Exception {
		Document document = crearXML();
	    try (Statement sentencia = conexion.createStatement()) {
	        String sql = "SELECT * FROM grupo";
	        try (ResultSet resul = sentencia.executeQuery(sql)) {
	            while (resul.next()) {
	                int idGrupo = resul.getInt("id");
	                String nombreGrupo = resul.getString("nombre");
	                
	                Element grupoElement = document.createElement("Grupo");
	                grupoElement.setAttribute("ID", String.valueOf(idGrupo));
	                grupoElement.setAttribute("Nombre", nombreGrupo);
	                
	                // Obtener los alumnos de este grupo
	                String sqlAlumnos = "SELECT * FROM alumno WHERE id_grupo = " + idGrupo;
	                try (ResultSet resulAlumnos = sentencia.executeQuery(sqlAlumnos)) {
	                    while (resulAlumnos.next()) {
	                        Element alumnoElement = document.createElement("Alumno");
	                        alumnoElement.setAttribute("NIA", String.valueOf(resulAlumnos.getInt("nia")));
	                        alumnoElement.setAttribute("Nombre", resulAlumnos.getString("nombre"));
	                        alumnoElement.setAttribute("Apellidos", resulAlumnos.getString("apellidos"));
	                        alumnoElement.setAttribute("Ciclo", resulAlumnos.getString("ciclo"));
	                        grupoElement.appendChild(alumnoElement);
	                    }
	                }
	                document.getDocumentElement().appendChild(grupoElement);
	            }
	        }
	        guardarXML(document);
	    }
	}

	public static Document crearXML() throws ParserConfigurationException {
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    DOMImplementation implementation = builder.getDOMImplementation();
	    return implementation.createDocument(null, "Alumnos", null);
	}

	public static void hacerElementosYAtributos(Document document, Element alumno, Alumnos alus) {
	    Element nuevoAlumno = document.createElement("Alumno");
	    nuevoAlumno.setAttribute("NIA", Integer.toString(alus.getNia()));

	    crearElemento("Nombre", alus.getNombre(), nuevoAlumno, document);
	    crearElemento("Apellidos", alus.getApellidos(), nuevoAlumno, document);
	    crearElemento("Genero", String.valueOf(alus.getGenero()), nuevoAlumno, document);
	    crearElemento("Fecha_Nacimiento", alus.getFecha_nacimiento().toString(), nuevoAlumno, document);

	    Element ciclo = document.createElement("Ciclo");
	    ciclo.setAttribute("Curso", alus.getCurso());
	    ciclo.setAttribute("Grupo", alus.getGrupo());
	    ciclo.setTextContent(alus.getCiclo());
	    nuevoAlumno.appendChild(ciclo);

	    document.getDocumentElement().appendChild(nuevoAlumno);
	}

	public static void guardarXML(Document document)
			throws TransformerConfigurationException, TransformerFactoryConfigurationError, TransformerException {
		Source source = new DOMSource(document);
		Result result = new StreamResult(new java.io.File("alumnos.xml"));
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		transformer.transform(source, result);
	}
	
	public static void eliminarAlumnoPorPalabra(Connection conexion,Scanner sc) {
		System.out.println("Escribe la palabra que quieras para eliminar a los alumnos que la contengan:");
		String palabra=sc.nextLine();
		palabra=sc.nextLine();
		try {
			Statement sentencia=conexion.createStatement();
			String sql="delete from alumno where Apellidos like'%"+palabra+"%';";
			int resul = sentencia.executeUpdate(sql);
			sentencia.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Apellidos eliminados.");
	}
	
	public static void eliminarAlumnoPorNia(Connection conexion,Scanner sc) {
		System.out.println("Escribe el NIA del alumno que quieres eliminar:");
		int nia=sc.nextInt();
		try {
			Statement sentencia=conexion.createStatement();
			String sql="delete from alumno where nia="+nia+";";
			int resul = sentencia.executeUpdate(sql);
			sentencia.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Alumno eliminado.");
	}
	
	public static void cambiarNombre(Connection conexion,Scanner sc) {
		System.out.println("Escribe el NIA del alumno que quieres cambiar el nombre:");
		int nia=sc.nextInt();
		System.out.println("Escribe el nuevo nombre: ");
		String nombre=sc.nextLine();
		nombre=sc.nextLine();
		try {
			Statement sentencia=conexion.createStatement();
			String sql="update alumno set Nombre=\""+nombre+"\" where nia="+nia+";";
			int resul = sentencia.executeUpdate(sql);
			sentencia.close(); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Nombre actualizado.");
	}
	
	public static void leerAlumnosBIN(Connection conexion,Scanner sc) {
		System.out.println("Escribe el nombre del fichero .bin (con ruta absoluta) que quieras leer:");
		String ruta=sc.nextLine();
		ruta=sc.nextLine();
		File fich=new File(ruta);
		try (ObjectInputStream ois= new ObjectInputStream(new FileInputStream(fich))){
			Alumnos alus;
			do {
				alus=(Alumnos)ois.readObject();
				if(alus!=null) {
					leerObjetodeFichBin(alus);
					Statement sentencia=conexion.createStatement();
					String sql="Insert into alumno values ("+alus.nia+",\""+alus.nombre+"\",\""+alus.apellidos+"\",\""+alus.genero+"\",\""+alus.fecha_nacimiento+"\",\""+alus.ciclo+"\",\""+alus.curso+"\",\""+alus.grupo+"\")";
					int resul = sentencia.executeUpdate(sql);
					sentencia.close(); 
				}
			}while(alus!=null);
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Se han insertado el alumno en la base de datos");
	}

	public static void leerObjetodeFichBin(Alumnos alus) {
		System.out.println("************");
		System.out.println("NIA: "+alus.getNia()+"\tNombre: "+alus.getNombre()+"\tApellidos: "+alus.getApellidos()+"\tGenero: "+alus.getGenero());
		System.out.println("Ciclo: "+alus.getCiclo()+"\tCurso: "+alus.getCurso()+"\tGrupo: "+alus.getGrupo());
		System.out.println("************");
	}
	
	public static void eliminarAlumnosPorCurso(Connection conexion, Scanner sc) {
	    System.out.println("Selecciona un curso para eliminar los alumnos:");
	    try {
	        Statement sentencia = conexion.createStatement();
	        String sql = "SELECT DISTINCT curso FROM alumno";
	        ResultSet result = sentencia.executeQuery(sql);
	        while (result.next()) {
	            System.out.println(result.getString("curso"));
	        }
	        
	        System.out.println("Escribe el curso que deseas eliminar: ");
	        String curso = sc.nextLine();
	        
	        sql = "DELETE FROM alumno WHERE curso = '" + curso + "'";
	        sentencia.executeUpdate(sql);
	        System.out.println("Alumnos del curso " + curso + " eliminados.");
	        sentencia.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	public static int hacerOpcionSeleccionada(Connection conexion, Scanner sc) {
		int opc;
		System.out.println("****************");
		System.out.println("Escribe lo que quieras realizar:");
		verOpc();
		opc=sc.nextInt();
		switch (opc) {
			case 1: {
				hacerAlumno(conexion);
				break;
			}
			case 2:{
				insertarGrupo(conexion);
				break;
			}
			case 3:{
				verAlumnosDeBase(conexion);
				break;
			}
			case 4:{
				guardarAlumnosEnBIN(conexion);
				break;
			}
			case 5:{
				leerAlumnosBIN(conexion,sc);
				break;
			}
			case 6:{
				cambiarNombre(conexion,sc);
				break;
			}
			case 7:{
				eliminarAlumnoPorNia(conexion,sc);
				break;
			}
			case 8:{
				eliminarAlumnoPorPalabra(conexion,sc);
			}
			case 9:{
				eliminarAlumnosPorCurso(conexion,sc);
				break;
			}
			case 10:{
				try {
					guardarEnXML(conexion);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
			case 11:{
				leerEnXML(conexion,sc);
				break;
			}
			case 12:{
				try {
					conexion.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
			default:
				System.out.println("Escribe un numero apropiado (1-10):");
				verOpc();
		}
		return opc;
	}

	public static Connection crearConex() throws ClassNotFoundException, SQLException {
		Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/alumnos04","root","Manager11");
		return conexion;
	}
}
