package ej11;

import java.io.Serializable;
import java.time.LocalDate;


public class Alumnos implements Serializable {
    private static final long serialVersionUID = 9065370148158893507L;

    public int nia;
    public int getNia() {
		return nia;
	}
	public void setNia(int nia) {
		this.nia = nia;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public char getGenero() {
		return genero;
	}
	public void setGenero(char genero) {
		this.genero = genero;
	}
	public LocalDate getFecha_nacimiento() {
		return fecha_nacimiento;
	}
	public void setFecha_nacimiento(LocalDate fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}
	public String getCiclo() {
		return ciclo;
	}
	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public int getGrupo() {
		return grupo;
	}
	public void setGrupo(int id_grupo) {
		this.grupo = id_grupo;
	}
	public String nombre, apellidos;
    public char genero;
    public LocalDate fecha_nacimiento;
    public String ciclo;
    public String curso; 
    public int grupo; 

    
}
