/**
 * 
 */
/**
 * 
 */
module tareasADBases {
	requires java.sql;
	requires java.xml;
	exports ej11;
}